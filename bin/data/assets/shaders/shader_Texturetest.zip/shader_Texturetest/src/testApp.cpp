#include "testApp.h"
//--------------------------------------------------------------
void testApp::setup(){
    
    ofSetLogLevel(OF_LOG_VERBOSE);
		ofSetVerticalSync(false);
	//ofEnableAlphaBlending();
    
   // ofDisableArbTex();
    
    camWidth=640;
    camHeight = 480;
    vidGrabber.initGrabber(camWidth, camHeight);
    tex1.allocate(camWidth,camHeight,GL_RGB);
    shader.load("shaders/brcosa.vert", "shaders/brcosa.frag");	
    shader.setUniform3f("avgluma", 0.62,0.62,0.62);
    shader.setUniform1f("contrast", 1.0);
    shader.setUniform1f("brightness", 1.0);
    shader.setUniform1f("saturation", 1.0);
    shader.setUniform1f("alpha", 1.0);

}

//--------------------------------------------------------------
void testApp::update(){
    vidGrabber.grabFrame();
    
    if (vidGrabber.isFrameNew()) {
        tex1=vidGrabber.getTextureReference();
    }
    
}

//--------------------------------------------------------------
void testApp::draw(){
    ofBackgroundGradient(ofColor::gray, ofColor::black);
    shader.begin();
        tex1.draw(0,0);
    shader.end();
}


//--------------------------------------------------------------
void testApp::keyPressed(int key){

}

//--------------------------------------------------------------
void testApp::keyReleased(int key){

}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void testApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void testApp::dragEvent(ofDragInfo dragInfo){ 

}